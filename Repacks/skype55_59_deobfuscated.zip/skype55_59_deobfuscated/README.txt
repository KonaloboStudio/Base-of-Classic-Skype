This package contains deobfuscated, unpacked Skype 5.5 and 5.9 binaries for Windows.

All anti-debugging code was removed so feel free to explore binaries.

It writes clear debug log, you can find many interesting there.

Use logging-on.reg for enabling this feature.


More here http://skype-open-source.blogspot.com/

skypeopensource@conference.jabber.ru

