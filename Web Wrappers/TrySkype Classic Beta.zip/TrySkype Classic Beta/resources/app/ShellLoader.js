"use strict";
const Helpers_1 = require('./Helpers');
const Templates_1 = require('./Templates');
const ShellSession_1 = require('./ShellSession');
const ShellEvents_1 = require('./ShellEvents');
const SplashScreen_1 = require('./SplashScreen');
const KeyboardNavigation_1 = require('./KeyboardNavigation');
const Notifications = require('./notifications/Notifications');
const ShellLocalization_1 = require('./localization/ShellLocalization');
const Sdk_1 = require('./Sdk');
const skype_electron_wrapper_1 = require('skype-electron-wrapper');
function apiForShell(skype) {
    skype.Shell = {};
    skype.Shell.Encoding = new Helpers_1.Encoding();
    skype.Shell.ShellSession = new ShellSession_1.ShellSession();
    let events = new ShellEvents_1.ShellEvents();
    let keyboardNavigation = new KeyboardNavigation_1.KeyboardNavigation(document);
    skype.Shell.SplashScreen = new SplashScreen_1.SplashScreen(keyboardNavigation, events);
    skype.ShellLocalization = new ShellLocalization_1.ShellLocalization();
    let templates = new Templates_1.Templates(document);
    Notifications.init(skype, events, templates, skype.ipcSend);
    const authenticationManager = skype_electron_wrapper_1.getAuthenticationManager();
    skype.Shell.ShellSession.updateAuthProperties(authenticationManager.getSkypeToken());
    skype.on('auth-data-updated', (authData) => {
        skype.Shell.ShellSession.updateAuthProperties(authData.skypeToken);
        if (skype.Shell.clearChatServiceToken && typeof skype.Shell.clearChatServiceToken === 'function') {
            skype.Shell.clearChatServiceToken();
        }
    });
    events.on('userPresenceChanged', (data) => {
        skype.ipcSend('userPresenceChanged', data);
    });
    events.on('unreadConversationsUpdate', (count) => {
        skype.ipcSend('badgeCount', count);
    });
    skype.Shell.Sdk = new Sdk_1.Sdk(skype.Shell.ShellSession, events, skype.Notifications.Title, skype.Notifications.Manager);
}
exports.apiForShell = apiForShell;
