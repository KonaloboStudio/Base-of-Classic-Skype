"use strict";
exports.soundConfig = {
    filesPath: 'file:///bundle/assets/audio/',
    supportedFormats: [
        {
            mimeType: 'audio/mp4',
            extension: 'm4a'
        },
        {
            mimeType: 'audio/ogg',
            extension: 'ogg'
        }
    ],
    fileIds: {
        incomingCall: 'call-incoming-loop',
        incomingMessage: 'message-received-1'
    }
};
