"use strict";
const skype_electron_wrapper_1 = require('skype-electron-wrapper');
let languagesList = [
    { locale: 'de_DE', optionTextKey: 'Languages.Lang_de' },
    { locale: 'en_US', optionTextKey: 'Languages.Lang_en' },
    { locale: 'es_ES', optionTextKey: 'Languages.Lang_es' },
    { locale: 'fr_FR', optionTextKey: 'Languages.Lang_fr' },
    { locale: 'hi_IN', optionTextKey: 'Languages.Lang_hi' },
    { locale: 'it_IT', optionTextKey: 'Languages.Lang_it' },
    { locale: 'nl_NL', optionTextKey: 'Languages.Lang_nl' },
    { locale: 'pt_BR', optionTextKey: 'Languages.Lang_pt-br' },
    { locale: 'ru_RU', optionTextKey: 'Languages.Lang_ru' },
    { locale: 'sv_SE', optionTextKey: 'Languages.Lang_sv' },
    { locale: 'uk_UA', optionTextKey: 'Languages.Lang_uk' },
    { locale: 'zh_CN', optionTextKey: 'Languages.Lang_zh-cn' }
];
let configuration = {
    environment: 'release',
    rootDir: __dirname,
    applicationUrl: '/main.html',
    applicationUrlNoCSP: '/main.nocsp.html',
    appShortName: skype_electron_wrapper_1.pickByPlatform('skypewebwrap', 'skypewebwrap', 'skypeforlinux'),
    appName: skype_electron_wrapper_1.pickByPlatform('Skype WebWrap', 'Skype WebWrap', 'Skype for Linux Alpha'),
    appNameTranslationKey: skype_electron_wrapper_1.pickByPlatform('Skype', 'Skype', 'ApplicationName'),
    appExeName: skype_electron_wrapper_1.pickByPlatform('Skype-WebWrap', 'Skype-WebWrap', 'skypeforlinux'),
    keychainService: 'Skype WebWrap',
    platformId: skype_electron_wrapper_1.pickByPlatform('1429', '1428', '1427'),
    appUserModelId: '',
    thrdPartyNoticesFile: '/usr/share/doc/skypeforlinux/third-party_attributions.html',
    biAppKey: skype_electron_wrapper_1.pickByPlatform('electron-win', 'electron-mac', 'electron-linux'),
    tenantToken: 'a173030604a34bdcbf21ca59134c7430-2a34e3b5-60e1-4a11-ad6d-2e9eac9ac07c-6614',
    enableUpdates: true,
    packageUrl: '/swx/js/fullExperience.min.js',
    debugMenuIncluded: false,
    debugMenuAddShortcut: true,
    ecsHost: 'downloads.tryskype.fun,downloads.tryskype.fun',
    showLoader: true,
    loadingPageUrl: 'file:///common/pages/loading.html',
    features: {
        trayIconFolder: 'tray',
        hasPresenceStatus: true,
        shouldUseOAuth: false
    },
    log: {
        enableLogging: false,
        consoleLogging: false,
        loggingLevel: skype_electron_wrapper_1.LogLevel.INFO
    },
    mainWindow: {
        shouldHideTheTopBar: false,
        minWidth: 320,
        minHeight: 480
    },
    hideInactiveMenuItems: false,
    crashReporterUrl: 'https://rink.hockeyapp.net/api/2/apps/18a36dbfcd4349099c48ee56bfe71897/crashes/upload',
    preload: 'Preload.js',
    localizationConfiguration: {
        localizationTablesPath: __dirname + '/translations',
        supportedLanguages: ['de', 'en', 'es', 'fr', 'hi', 'it', 'nl', 'pt-br', 'ru', 'sv', 'uk', 'zh-cn'],
        localeSelectionMenuItems: languagesList
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = configuration;
