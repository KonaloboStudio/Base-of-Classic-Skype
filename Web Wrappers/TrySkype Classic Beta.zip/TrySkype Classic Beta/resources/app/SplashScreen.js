"use strict";
const Helpers_1 = require('./Helpers');
const Config_1 = require('./Config');
class SplashScreen {
    constructor(keyboardNavigation, shellEvents) {
        this.splashScreenIsVisible = true;
        this.keyboardNavigation = keyboardNavigation;
        this.shellEvents = shellEvents;
    }
    show() {
        if (!this.splashScreenElem) {
            this.splashScreenElem = document.getElementById('shellSplashScreen');
        }
        Helpers_1.Ui.makePageInvisibleForAT(this.splashScreenElem);
        document.querySelector('.shellSplashLoading').focus();
        this.keyboardNavigation.restrictTabbing([this.splashScreenElem]);
        let timer = window.setTimeout(() => { this.hideSplashScreen(); }, Config_1.config.splashScreenDisplayTime);
        this.shellEvents.subscribe('pageRendered', () => {
            this.hideSplashScreen();
            window.clearTimeout(timer);
        });
    }
    hideSplashScreen() {
        let body = document.body;
        if (!this.splashScreenIsVisible) {
            return;
        }
        this.keyboardNavigation.liftLastRestriction();
        Helpers_1.Ui.addClass(this.splashScreenElem, 'splashScreenFade');
        window.setTimeout(() => {
            if (this.splashScreenElem.parentNode !== null) {
                this.splashScreenElem.parentNode.removeChild(this.splashScreenElem);
            }
        }, 400);
        body.tabIndex = -1;
        body.focus();
        Helpers_1.Ui.makePageVisibleForAT();
        this.shellEvents.publish('splashScreenHidden');
        this.splashScreenIsVisible = false;
    }
}
exports.SplashScreen = SplashScreen;
