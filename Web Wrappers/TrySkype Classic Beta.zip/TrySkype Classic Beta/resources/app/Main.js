"use strict";
const Configuration_1 = require('./Configuration');
const skype_electron_wrapper_1 = require('skype-electron-wrapper');
const electron_1 = require('electron');
if (process.platform === 'linux') {
    electron_1.crashReporter.start({
        productName: Configuration_1.default.appShortName,
        companyName: 'Skype',
        submitURL: Configuration_1.default.crashReporterUrl,
        autoSubmit: true,
        extra: {
            environment: Configuration_1.default.environment
        }
    });
}
const app = skype_electron_wrapper_1.createApp(Configuration_1.default);
app.start();
