/*globals Skype*/
define(function (require) {
    'use strict';

    var loader = require('swx-utils-common').loader,
        settings = require('experience/settings'),
        i18nResources = require('swx-i18n').resources,
        pluralizer = require('services/i18n/pluralizer'),
        cultureInfo = require('services/i18n/cultureInfo'),
        constants = require('swx-constants').COMMON,
        defaultTranslation = require('services/i18n/swx/default');

    function Loader() {
        var self = this,
            CONSTANT_FORWARD_SLASH = '/',
            CONSTANT_STRINGS = 'Strings.js',
            CONSTANT_STRINGS_LOWERCASE = 'strings.js';

        function onSuccess(lang) {
            settings.locale = settings.locale || {};
            settings.locale.i18n = lang;
        }

        /**
         * Tries to load the localized strings definition for a language code. It tries the exact code (ex. en-gb),
         *   then the lower case version of the file (strings.js instead of String.js), then tries to fall back to the
         *   primary language code (ex. en), then finally uses the default localized strings (en-us).
         * @param localizationUrl - base URL of Strings.js file
         * @param variant - variant identifier (eg. swx)
         * @param lang - IETF language tag (eg. en-us)
         * @returns a Promise that is resolved when the resources have been loaded
         */
        self.load = function (localizationUrl, variant, lang) {
            var translationsUrl = localizationUrl + CONSTANT_FORWARD_SLASH + variant + CONSTANT_FORWARD_SLASH + lang + CONSTANT_FORWARD_SLASH + CONSTANT_STRINGS;

            Skype.WebExperience = Skype.WebExperience || {};
            Skype.WebExperience.setTranslations = function (dictionary) {
                i18nResources.merge(dictionary);
            };
            pluralizer.init(lang);

            function loadScript(url) {
                return new Promise(function (res, rej) {
                    loader.loadScript(url, res, rej);
                });
            }

            function defaultLanguageFallback() {
                i18nResources.set(defaultTranslation);
                return constants.i18n.EMBEDDED_LOCALE;
            }

            function tryBackupLanguage() {
                var backupLanguage = cultureInfo.getLocale(lang),
                    uri = localizationUrl + CONSTANT_FORWARD_SLASH + variant + CONSTANT_FORWARD_SLASH + backupLanguage + CONSTANT_FORWARD_SLASH + CONSTANT_STRINGS;

                return loadScript(uri).then(function () { return lang; });
            }

            function tryLowercaseLanguageFile() {
                var uri = localizationUrl + CONSTANT_FORWARD_SLASH + variant + CONSTANT_FORWARD_SLASH + lang + CONSTANT_FORWARD_SLASH + CONSTANT_STRINGS_LOWERCASE;
                return loadScript(uri).then(function () { return lang; });
            }

            return loadScript(translationsUrl).then(function () { return lang; })
                .catch(tryLowercaseLanguageFile)
                .catch(tryBackupLanguage)
                .catch(defaultLanguageFallback)
                .then(onSuccess.bind(null));
        };
    }

    return new Loader();
});
