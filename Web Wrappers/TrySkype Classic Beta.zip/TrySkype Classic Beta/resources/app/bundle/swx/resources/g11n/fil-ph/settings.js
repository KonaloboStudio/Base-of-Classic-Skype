Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["Linggo", "Lunes", "Martes", "Miyerkules", "Huwebes", "Biyernes", "Sabado"],
            namesAbbr: ["Lin", "Lun", "Mar", "Miy", "Huw", "Biy", "Sab"]
        },
        months: {
            names: ["Enero", "Pebrero", "Marso", "Abril", "Mayo", "Hunyo", "Hulyo", "Agosto", "Setyembre", "Oktubre", "Nobyembre", "Disyembre"],
            namesAbbr: ["Ene", "Peb", "Mar", "Abr", "Mayo", "Hun", "Hul", "Ago", "Set", "Okt", "Nob", "Dis"]
        },
        firstDay: 0
    },
    time : {
        AM: "AM",
        PM: "PM",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "h:mm tt",
            long: "h:mm:ss tt"
        }
    },
    date: {
        separator: "/",
        format: {
            dayMonth: "M/d",
            dayMonthYear: "M/d/yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "mAbbr d yyyy",
            shortDateAbbr: "mAbbr d"
        }
    },
    dir: "ltr"
});


