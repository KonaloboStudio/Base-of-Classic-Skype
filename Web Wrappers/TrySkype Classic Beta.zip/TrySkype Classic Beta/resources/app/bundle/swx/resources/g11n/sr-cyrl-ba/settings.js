Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["недјеља", "понедјељак", "уторак", "сриједа", "четвртак", "петак", "субота"],
            namesAbbr: ["нед", "пон", "уто", "сри", "чет", "пет", "суб"]
        },
        months: {
            names: ["јануар", "фебруар", "март", "април", "мај", "јуни", "јули", "август", "септембар", "октобар", "новембар", "децембар"],
            namesAbbr: ["јан", "феб", "мар", "апр", "мај", "јун", "јул", "авг", "сеп", "окт", "нов", "дец"]
        },
        firstDay: 1
    },
    time : {
        AM: "",
        PM: "",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "H:mm",
            long: "H:mm:ss"
        }
    },
    date: {
        separator: ".",
        format: {
            dayMonth: "d.M",
            dayMonthYear: "d.M.yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "ltr"
});


