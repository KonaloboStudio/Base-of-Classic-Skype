Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["неделя", "понеделник", "вторник", "сряда", "четвъртък", "петък", "събота"],
            namesAbbr: ["нед", "пон", "вт", "ср", "четв", "пет", "съб"]
        },
        months: {
            names: ["януари", "февруари", "март", "април", "май", "юни", "юли", "август", "септември", "октомври", "ноември", "декември"],
            namesAbbr: ["яну", "фев", "мар", "апр", "май", "юни", "юли", "авг", "сеп", "окт", "ное", "дек"]
        },
        firstDay: 1
    },
    time : {
        AM: "",
        PM: "",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "H:mm",
            long: "H:mm:ss"
        }
    },
    date: {
        separator: ".",
        format: {
            dayMonth: "d.M",
            dayMonthYear: "d.M.yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "ltr"
});


