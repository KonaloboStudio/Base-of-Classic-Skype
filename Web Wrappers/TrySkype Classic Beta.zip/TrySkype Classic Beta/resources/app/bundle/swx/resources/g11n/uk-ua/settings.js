Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["неділя", "понеділок", "вівторок", "середа", "четвер", "п'ятниця", "субота"],
            namesAbbr: ["Нд", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб"]
        },
        months: {
            names: ["січня", "лютого", "березня", "квітня", "травня", "червня", "липня", "серпня", "вересня", "жовтня", "листопада", "грудня"],
            namesAbbr: ["січ", "лют", "бер", "кві", "тра", "чер", "лип", "сер", "вер", "жов", "лис", "гру"]
        },
        firstDay: 1
    },
    time : {
        AM: "",
        PM: "",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "H:mm",
            long: "H:mm:ss"
        }
    },
    date: {
        separator: ".",
        format: {
            dayMonth: "d.M",
            dayMonthYear: "d.M.yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "ltr"
});


