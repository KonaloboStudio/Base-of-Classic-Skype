Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["sekmadienis", "pirmadienis", "antradienis", "trečiadienis", "ketvirtadienis", "penktadienis", "šeštadienis"],
            namesAbbr: ["Sk", "Pr", "An", "Tr", "Kt", "Pn", "Št"]
        },
        months: {
            names: ["sausio", "vasario", "kovo", "balandžio", "gegužės", "birželio", "liepos", "rugpjūčio", "rugsėjo", "spalio", "lapkričio", "gruodžio"],
            namesAbbr: ["Sau", "Vas", "Kov", "Bal", "Geg", "Bir", "Lie", "Rgp", "Rgs", "Spl", "Lap", "Grd"]
        },
        firstDay: 1
    },
    time : {
        AM: "",
        PM: "",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "HH:mm",
            long: "HH:mm:ss"
        }
    },
    date: {
        separator: "-",
        format: {
            dayMonth: "M-d",
            dayMonthYear: "M-d-yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "mAbbr d yyyy",
            shortDateAbbr: "mAbbr d"
        }
    },
    dir: "ltr"
});


