define(function (require) {
    'use strict';

    var i18nResources = require('swx-i18n').resources,
        defaultTranslation = require('services/i18n/swx/default'),
        i18nPluralizer = require('services/i18n/pluralizer'),
        constants = require('swx-constants').COMMON,
        i18nLoader = require('services/i18n/loader');

    var DEFAULT_LANGUAGE = constants.i18n.EMBEDDED_LOCALE,
        DEFAULT_VARIANT = 'swx';

    function I18N() {

        var self = this;

        /**
         * Loads the localized resources from the server
         * @param settings gets information from settings.appBaseUrl, settings.initParams.locale
         *   and settings.initParams.variant. Fills settings.locale upon return
         * @param root sets the lang attribute
         * @returns a Promise? that resolves when all the resources for the language have been loaded or undefined if
         *   the default language (en-us) is used.
         */
        self.init = function (settings, root) {

            var localizationUrl,
                lang = settings.initParams.locale,
                variant = settings.initParams.variant;

            if (!root.lang) {
                root.lang = lang;
            }

            if (lang === DEFAULT_LANGUAGE && variant === DEFAULT_VARIANT) {
                settings.locale = settings.locale || {};
                settings.locale.i18n = lang;
                return Promise.resolve();
            } else {
                localizationUrl = settings.appBaseUrl + '/resources/i18n';
                return i18nLoader.load(localizationUrl, variant, lang);
            }
        };

        // load the bundled resources by default
        i18nResources.set(defaultTranslation);
        i18nPluralizer.init(DEFAULT_LANGUAGE);
    }

    return new I18N();
});
