Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["e diel", "e hënë", "e martë", "e mërkurë", "e enjte", "e premte", "e shtunë"],
            namesAbbr: ["Die", "Hën", "Mar", "Mër", "Enj", "Pre", "Sht"]
        },
        months: {
            names: ["janar", "shkurt", "mars", "prill", "maj", "qershor", "korrik", "gusht", "shtator", "tetor", "nëntor", "dhjetor"],
            namesAbbr: ["Jan", "Shk", "Mar", "Pri", "Maj", "Qer", "Krr", "Gsh", "Sht", "Tet", "Nën", "Dhj"]
        },
        firstDay: 1
    },
    time : {
        AM: "PD",
        PM: "MD",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "HH:mm",
            long: "HH:mm:ss"
        }
    },
    date: {
        separator: ".",
        format: {
            dayMonth: "d.M",
            dayMonthYear: "d.M.yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "ltr"
});


