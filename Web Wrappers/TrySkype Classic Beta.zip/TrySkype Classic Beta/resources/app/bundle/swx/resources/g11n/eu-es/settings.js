Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["igandea", "astelehena", "asteartea", "asteazkena", "osteguna", "ostirala", "larunbata"],
            namesAbbr: ["ig.", "al.", "as.", "az.", "og.", "or.", "lr."]
        },
        months: {
            names: ["urtarrila", "otsaila", "martxoa", "apirila", "maiatza", "ekaina", "uztaila", "abuztua", "iraila", "urria", "azaroa", "abendua"],
            namesAbbr: ["urt.", "ots.", "mar.", "api.", "mai.", "eka.", "uzt.", "abu.", "ira.", "urr.", "aza.", "abe."]
        },
        firstDay: 1
    },
    time : {
        AM: "",
        PM: "",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "H:mm",
            long: "H:mm:ss"
        }
    },
    date: {
        separator: "/",
        format: {
            dayMonth: "M/d",
            dayMonthYear: "M/d/yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "mAbbr d yyyy",
            shortDateAbbr: "mAbbr d"
        }
    },
    dir: "ltr"
});


