Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["ରବିବାର", "ସୋମବାର", "ମଙ୍ଗଳବାର", "ବୁଧବାର", "ଗୁରୁବାର", "ଶୁକ୍ରବାର", "ଶନିବାର"],
            namesAbbr: ["ରବି.", "ସୋମ.", "ମଙ୍ଗଳ.", "ବୁଧ.", "ଗୁରୁ.", "ଶୁକ୍ର.", "ଶନି."]
        },
        months: {
            names: ["ଜାନୁୟାରୀ", "ଫେବୃଆରୀ", "ମାର୍ଚ୍ଚ", "ଏପ୍ରିଲ୍‌", "ମେ", "ଜୁନ୍‌", "ଜୁଲାଇ", "ଅଗଷ୍ଟ", "ସେପ୍ଟେମ୍ବର", "ଅକ୍ଟୋବର", "ନଭେମ୍ବର", "ଡିସେମ୍ବର"],
            namesAbbr: ["ଜାନୁୟାରୀ", "ଫେବୃଆରୀ", "ମାର୍ଚ୍ଚ", "ଏପ୍ରିଲ୍‌", "ମେ", "ଜୁନ୍‌", "ଜୁଲାଇ", "ଅଗଷ୍ଟ", "ସେପ୍ଟେମ୍ବର", "ଅକ୍ଟୋବର", "ନଭେମ୍ବର", "ଡିସେମ୍ବର"]
        },
        firstDay: 1
    },
    time : {
        AM: "AM",
        PM: "PM",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "HH:mm",
            long: "HH:mm:ss"
        }
    },
    date: {
        separator: "-",
        format: {
            dayMonth: "d-M",
            dayMonthYear: "d-M-yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "ltr"
});


