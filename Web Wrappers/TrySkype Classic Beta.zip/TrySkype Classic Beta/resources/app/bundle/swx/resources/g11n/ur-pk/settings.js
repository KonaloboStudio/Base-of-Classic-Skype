Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["اتوار", "پير", "منگل", "بدھ", "جمعرات", "جمعه", "هفته"],
            namesAbbr: ["اتوار", "پير", "منگل", "بدھ", "جمعرات", "جمعه", "هفته"]
        },
        months: {
            names: ["جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"],
            namesAbbr: ["جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"]
        },
        firstDay: 1
    },
    time : {
        AM: "AM",
        PM: "PM",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "h:mm tt",
            long: "h:mm:ss tt"
        }
    },
    date: {
        separator: "/",
        format: {
            dayMonth: "d/M",
            dayMonthYear: "d/M/yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "rtl"
});


