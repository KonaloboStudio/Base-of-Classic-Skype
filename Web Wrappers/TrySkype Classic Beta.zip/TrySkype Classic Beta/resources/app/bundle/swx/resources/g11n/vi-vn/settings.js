Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["Chủ Nhật", "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy"],
            namesAbbr: ["CN", "T2", "T3", "Tư", "Năm", "Sáu", "Bảy"]
        },
        months: {
            names: ["Tháng Giêng", "Tháng Hai", "Tháng Ba", "Tháng Tư", "Tháng Năm", "Tháng Sáu", "Tháng Bảy", "Tháng Tám", "Tháng Chín", "Tháng Mười", "Tháng Mười Một", "Tháng Mười Hai"],
            namesAbbr: ["Thg1", "Thg2", "Thg3", "Thg4", "Thg5", "Thg6", "Thg7", "Thg8", "Thg9", "Thg10", "Thg11", "Thg12"]
        },
        firstDay: 1
    },
    time : {
        AM: "SA",
        PM: "CH",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "h:mm tt",
            long: "h:mm:ss tt"
        }
    },
    date: {
        separator: "/",
        format: {
            dayMonth: "d/M",
            dayMonthYear: "d/M/yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "ltr"
});


