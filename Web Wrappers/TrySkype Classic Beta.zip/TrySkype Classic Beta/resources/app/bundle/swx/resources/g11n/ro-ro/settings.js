Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["duminică", "luni", "marți", "miercuri", "joi", "vineri", "sâmbătă"],
            namesAbbr: ["D", "L", "Ma", "Mi", "J", "V", "S"]
        },
        months: {
            names: ["ianuarie", "februarie", "martie", "aprilie", "mai", "iunie", "iulie", "august", "septembrie", "octombrie", "noiembrie", "decembrie"],
            namesAbbr: ["ian.", "feb.", "mar.", "apr.", "mai.", "iun.", "iul.", "aug.", "sep.", "oct.", "nov.", "dec."]
        },
        firstDay: 1
    },
    time : {
        AM: "a.m.",
        PM: "p.m.",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "H:mm",
            long: "H:mm:ss"
        }
    },
    date: {
        separator: ".",
        format: {
            dayMonth: "d.M",
            dayMonthYear: "d.M.yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "ltr"
});


