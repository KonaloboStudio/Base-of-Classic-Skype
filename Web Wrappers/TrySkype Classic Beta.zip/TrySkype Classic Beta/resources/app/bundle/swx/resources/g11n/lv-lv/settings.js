Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["svētdiena", "pirmdiena", "otrdiena", "trešdiena", "ceturtdiena", "piektdiena", "sestdiena"],
            namesAbbr: ["sv", "pr", "ot", "tr", "ce", "pk", "se"]
        },
        months: {
            names: ["janvāris", "februāris", "marts", "aprīlis", "maijs", "jūnijs", "jūlijs", "augusts", "septembris", "oktobris", "novembris", "decembris"],
            namesAbbr: ["jan", "feb", "mar", "apr", "mai", "jūn", "jūl", "aug", "sep", "okt", "nov", "dec"]
        },
        firstDay: 1
    },
    time : {
        AM: "",
        PM: "",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "H:mm",
            long: "H:mm:ss"
        }
    },
    date: {
        separator: ".",
        format: {
            dayMonth: "d.M",
            dayMonthYear: "d.M.yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "ltr"
});


