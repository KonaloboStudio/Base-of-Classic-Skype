Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["nedeľa", "pondelok", "utorok", "streda", "štvrtok", "piatok", "sobota"],
            namesAbbr: ["ne", "po", "ut", "st", "št", "pi", "so"]
        },
        months: {
            names: ["januára", "februára", "marca", "apríla", "mája", "júna", "júla", "augusta", "septembra", "októbra", "novembra", "decembra"],
            namesAbbr: ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"]
        },
        firstDay: 1
    },
    time : {
        AM: "dop.",
        PM: "odp.",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "H:mm",
            long: "H:mm:ss"
        }
    },
    date: {
        separator: ".",
        format: {
            dayMonth: "d.M",
            dayMonthYear: "d.M.yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d.mAbbr.yyyy",
            shortDateAbbr: "d.mAbbr."
        }
    },
    dir: "ltr"
});


