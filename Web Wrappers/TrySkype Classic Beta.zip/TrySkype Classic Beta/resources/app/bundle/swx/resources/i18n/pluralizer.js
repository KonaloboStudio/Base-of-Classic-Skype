define(function (require) {
    'use strict';

    var knockoutBindingExtensions = require('swx-i18n').knockoutBindingExtensions,
        businessAwareL10n = require('bindings/ko.businessAwareL10n'),
        i18nPlurals = require('swx-i18n').plurals,
        ko = require('vendor/knockout');

    function Pluralizer() {

        var self = this;

        self.init = function (lang) {

            var splits, pluralizeLang = lang.replace('-', '_').toLowerCase();
            var supportedLocale = i18nPlurals.pluralizationLocale[pluralizeLang];
            if (supportedLocale) {
                pluralizeLang = supportedLocale;
            }
            else {
                splits = pluralizeLang.split('_');
                if (splits.length === 1) {
                    throw new Error('Unsupported language:' + lang);
                }

                pluralizeLang = splits[0];
            }

            i18nPlurals.setLocale(pluralizeLang);
            knockoutBindingExtensions.init(ko);
            businessAwareL10n.register();
        };
    }

    return new Pluralizer();

});
