Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["söndag", "måndag", "tisdag", "onsdag", "torsdag", "fredag", "lördag"],
            namesAbbr: ["sön", "mån", "tis", "ons", "tor", "fre", "lör"]
        },
        months: {
            names: ["januari", "februari", "mars", "april", "maj", "juni", "juli", "augusti", "september", "oktober", "november", "december"],
            namesAbbr: ["jan", "feb", "mar", "apr", "maj", "jun", "jul", "aug", "sep", "okt", "nov", "dec"]
        },
        firstDay: 1
    },
    time : {
        AM: "",
        PM: "",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "HH:mm",
            long: "HH:mm:ss"
        }
    },
    date: {
        separator: "-",
        format: {
            dayMonth: "M-d",
            dayMonthYear: "M-d-yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "mAbbr d yyyy",
            shortDateAbbr: "mAbbr d"
        }
    },
    dir: "ltr"
});


