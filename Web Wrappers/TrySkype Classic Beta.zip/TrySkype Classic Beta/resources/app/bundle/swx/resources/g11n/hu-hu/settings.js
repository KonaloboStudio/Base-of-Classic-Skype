Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["vasárnap", "hétfő", "kedd", "szerda", "csütörtök", "péntek", "szombat"],
            namesAbbr: ["V", "H", "K", "Sze", "Cs", "P", "Szo"]
        },
        months: {
            names: ["január", "február", "március", "április", "május", "június", "július", "augusztus", "szeptember", "október", "november", "december"],
            namesAbbr: ["jan.", "febr.", "márc.", "ápr.", "máj.", "jún.", "júl.", "aug.", "szept.", "okt.", "nov.", "dec."]
        },
        firstDay: 1
    },
    time : {
        AM: "de.",
        PM: "du.",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "H:mm",
            long: "H:mm:ss"
        }
    },
    date: {
        separator: ".",
        format: {
            dayMonth: "M.d",
            dayMonthYear: "M.d.yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "mAbbr d yyyy",
            shortDateAbbr: "mAbbr d"
        }
    },
    dir: "ltr"
});


