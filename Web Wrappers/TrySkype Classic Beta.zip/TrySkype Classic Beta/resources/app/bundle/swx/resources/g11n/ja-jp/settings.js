Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["日曜日", "月曜日", "火曜日", "水曜日", "木曜日", "金曜日", "土曜日"],
            namesAbbr: ["日", "月", "火", "水", "木", "金", "土"]
        },
        months: {
            names: ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"],
            namesAbbr: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"]
        },
        firstDay: 0
    },
    time : {
        AM: "午前",
        PM: "午後",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "H:mm",
            long: "H:mm:ss"
        }
    },
    date: {
        separator: "/",
        format: {
            dayMonth: "M/d",
            dayMonthYear: "M/d/yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "mAbbr d yyyy",
            shortDateAbbr: "mAbbr d"
        }
    },
    dir: "ltr"
});


