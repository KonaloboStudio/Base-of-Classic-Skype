Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["sunnudagur", "mánudagur", "þriðjudagur", "miðvikudagur", "fimmtudagur", "föstudagur", "laugardagur"],
            namesAbbr: ["sun.", "mán.", "þri.", "mið.", "fim.", "fös.", "lau."]
        },
        months: {
            names: ["janúar", "febrúar", "mars", "apríl", "maí", "júní", "júlí", "ágúst", "september", "október", "nóvember", "desember"],
            namesAbbr: ["jan.", "feb.", "mar.", "apr.", "maí", "jún.", "júl.", "ágú.", "sep.", "okt.", "nóv.", "des."]
        },
        firstDay: 1
    },
    time : {
        AM: "",
        PM: "",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "HH:mm",
            long: "HH:mm:ss"
        }
    },
    date: {
        separator: ".",
        format: {
            dayMonth: "d.M",
            dayMonthYear: "d.M.yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "ltr"
});


