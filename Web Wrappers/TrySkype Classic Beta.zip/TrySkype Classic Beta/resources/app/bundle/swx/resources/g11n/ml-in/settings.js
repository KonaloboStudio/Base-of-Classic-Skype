Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["ഞായറാഴ്ച", "തിങ്കളാഴ്ച", "ചൊവ്വാഴ്ച", "ബുധനാഴ്ച", "വ്യാഴാഴ്ച", "വെള്ളിയാഴ്ച", "ശനിയാഴ്ച"],
            namesAbbr: ["ഞായർ.", "തിങ്കൾ.", "ചൊവ്വ.", "ബുധൻ.", "വ്യാഴം.", "വെള്ളി.", "ശനി."]
        },
        months: {
            names: ["ജനുവരി", "ഫെബ്രുവരി", "മാര്‍‌ച്ച്", "ഏപ്രില്‍", "മെയ്", "ജൂണ്‍", "ജൂലൈ", "ആഗസ്റ്റ്", "സെപ്‌റ്റംബര്‍", "ഒക്‌ടോബര്‍", "നവംബര്‍", "ഡിസംബര്‍"],
            namesAbbr: ["ജനുവരി", "ഫെബ്രുവരി", "മാര്‍‌ച്ച്", "ഏപ്രില്‍", "മെയ്", "ജൂണ്‍", "ജൂലൈ", "ആഗസ്റ്റ്", "സെപ്‌റ്റംബര്‍", "ഒക്‌ടോബര്‍", "നവംബര്‍", "ഡിസംബര്‍"]
        },
        firstDay: 1
    },
    time : {
        AM: "AM",
        PM: "PM",
        separator: ".",
        format: {
            duration: "mm.ss",
            short: "HH.mm",
            long: "HH.mm.ss"
        }
    },
    date: {
        separator: "-",
        format: {
            dayMonth: "d-M",
            dayMonthYear: "d-M-yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "ltr"
});


