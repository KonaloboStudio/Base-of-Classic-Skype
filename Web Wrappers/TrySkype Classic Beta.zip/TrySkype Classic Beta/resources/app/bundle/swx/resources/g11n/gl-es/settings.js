Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["domingo", "luns", "martes", "mércores", "xoves", "venres", "sábado"],
            namesAbbr: ["dom", "luns", "mar", "mér", "xov", "ven", "sáb"]
        },
        months: {
            names: ["xaneiro", "febreiro", "marzo", "abril", "maio", "xuño", "xullo", "agosto", "setembro", "outubro", "novembro", "decembro"],
            namesAbbr: ["xan", "feb", "mar", "abr", "maio", "xuño", "xul", "ago", "set", "out", "nov", "dec"]
        },
        firstDay: 1
    },
    time : {
        AM: "a.m.",
        PM: "p.m.",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "H:mm",
            long: "H:mm:ss"
        }
    },
    date: {
        separator: "/",
        format: {
            dayMonth: "d/M",
            dayMonthYear: "d/M/yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "ltr"
});


