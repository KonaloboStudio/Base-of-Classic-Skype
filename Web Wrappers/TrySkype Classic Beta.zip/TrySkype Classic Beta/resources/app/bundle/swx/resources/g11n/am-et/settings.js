Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["እሑድ", "ሰኞ", "ማክሰኞ", "ረቡዕ", "ሐሙስ", "ዓርብ", "ቅዳሜ"],
            namesAbbr: ["እሑድ", "ሰኞ", "ማክሰ", "ረቡዕ", "ሐሙስ", "ዓርብ", "ቅዳሜ"]
        },
        months: {
            names: ["ጥር", "የካቲት", "መጋቢት", "ሚያዚያ", "ግንቦት", "ሰኔ", "ሐምሌ", "ነሐሴ", "መስከረም", "ጥቅምት", "ህዳር", "ታህሳስ"],
            namesAbbr: ["ጥር", "የካ.", "መጋ.", "ሚያ.", "ግን.", "ሰኔ", "ሐም.", "ነሐ.", "መስ.", "ጥቅ.", "ህዳ.", "ታህ."]
        },
        firstDay: 1
    },
    time : {
        AM: "ጧት",
        PM: "ከሰዓት በኋላ",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "h:mm tt",
            long: "h:mm:ss tt"
        }
    },
    date: {
        separator: "/",
        format: {
            dayMonth: "d/M",
            dayMonthYear: "d/M/yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "d mAbbr yyyy",
            shortDateAbbr: "d mAbbr"
        }
    },
    dir: "ltr"
});


