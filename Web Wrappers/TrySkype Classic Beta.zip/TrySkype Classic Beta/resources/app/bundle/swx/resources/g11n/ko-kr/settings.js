Skype && Skype.WebExperience && Skype.WebExperience.setGlobalization({

    calendar : {
        days : {
            names: ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"],
            namesAbbr: ["일", "월", "화", "수", "목", "금", "토"]
        },
        months: {
            names: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
            namesAbbr: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"]
        },
        firstDay: 0
    },
    time : {
        AM: "오전",
        PM: "오후",
        separator: ":",
        format: {
            duration: "mm:ss",
            short: "tt h:mm",
            long: "tt h:mm:ss"
        }
    },
    date: {
        separator: "-",
        format: {
            dayMonth: "M-d",
            dayMonthYear: "M-d-yy",
            dayAbbr: "dAbbr",
            dayName: "dName",
            dateAbbr: "mAbbr d yyyy",
            shortDateAbbr: "mAbbr d"
        }
    },
    dir: "ltr"
});


