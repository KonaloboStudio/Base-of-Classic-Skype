"use strict";
const events_1 = require('events');
class ShellEvents extends events_1.EventEmitter {
    subscribe(topic, func) {
        this.on(topic, func);
    }
    publish(topic, ...args) {
        this.emit(topic, ...args);
    }
}
exports.ShellEvents = ShellEvents;
