"use strict";
class Title {
    constructor(defaultTitle) {
        this.defaultTitle = defaultTitle;
    }
    display(title) {
        document.title = title;
    }
    ;
    reset() {
        document.title = this.defaultTitle;
    }
}
exports.Title = Title;
