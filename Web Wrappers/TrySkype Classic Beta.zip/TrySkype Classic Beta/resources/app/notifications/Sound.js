"use strict";
const SoundConfig_1 = require('../SoundConfig');
class Sound {
    constructor() {
        this.cachedAudioElements = {};
    }
    play(fileId, loop) {
        if (SoundConfig_1.soundConfig.fileIds.hasOwnProperty(fileId) === false) {
            return false;
        }
        let audioElement = this.getAudioElement(fileId);
        if (loop === true) {
            audioElement.setAttribute('loop', 'loop');
        }
        else {
            audioElement.removeAttribute('loop');
        }
        audioElement.play();
        return true;
    }
    stop(fileId) {
        if (SoundConfig_1.soundConfig.fileIds.hasOwnProperty(fileId) === false) {
            return false;
        }
        let audioElement = this.getAudioElement(fileId);
        audioElement.pause();
        audioElement.currentTime = 0;
        return true;
    }
    stopAll() {
        let cachedFileIds = Object.keys(this.cachedAudioElements);
        for (let i = 0; i < cachedFileIds.length; i++) {
            this.stop(cachedFileIds[i]);
        }
    }
    getCachedAudioElements() {
        return this.cachedAudioElements;
    }
    clearCachedAudioElements() {
        this.cachedAudioElements = {};
    }
    getFileUrl(fileId, extension) {
        return SoundConfig_1.soundConfig.filesPath + extension + '/' + SoundConfig_1.soundConfig.fileIds[fileId] + '.' + extension;
    }
    createAudioElement(fileId) {
        let audioElement = document.createElement('audio');
        for (let i = 0; i < SoundConfig_1.soundConfig.supportedFormats.length; i++) {
            let format = SoundConfig_1.soundConfig.supportedFormats[i];
            let url = this.getFileUrl(fileId, format.extension);
            let sourceElement = document.createElement('source');
            sourceElement.setAttribute('type', format.mimeType);
            sourceElement.setAttribute('src', url);
            audioElement.appendChild(sourceElement);
        }
        return audioElement;
    }
    getAudioElement(fileId) {
        if (!this.cachedAudioElements.hasOwnProperty(fileId)) {
            this.cachedAudioElements[fileId] = this.createAudioElement(fileId);
        }
        return this.cachedAudioElements[fileId];
    }
}
exports.Sound = Sound;
