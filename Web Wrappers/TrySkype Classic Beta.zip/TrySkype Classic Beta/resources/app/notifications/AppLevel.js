"use strict";
const Dom = require('../utils/Dom');
const notificationTypes = ['warning', 'success', 'error', 'info'];
class AppLevel {
    constructor(events) {
        this.activeNotifications = {};
        this.notificationNumber = 0;
        this.events = events;
    }
    display(type, message, actionText, action) {
        this.dismissAll();
        this.setNotificationsContainer();
        let notification = this.createNotification(type);
        let notificationId = this.getIdForNewNotification();
        notification.setAttribute('data-notification-id', notificationId);
        this.addIcon(notification);
        let messageContainer = this.addMessage(notification, message);
        this.addAction(messageContainer, notificationId, actionText, action);
        this.addDismissButton(notification, notificationId);
        this.notificationsContainer.appendChild(notification);
        this.activeNotifications[notificationId] = notification;
        this.events.publish('notificationDisplayed', notificationId);
        return notificationId;
    }
    dismiss(notificationId) {
        let notificationDismissed = this.dismissNotification(notificationId);
        return notificationDismissed;
    }
    getDisplayedNotifications() {
        return this.activeNotifications;
    }
    dismissAll() {
        for (let notificationId in this.activeNotifications) {
            if (this.activeNotifications.hasOwnProperty(notificationId)) {
                this.dismiss(notificationId);
            }
        }
    }
    setNotificationsContainer() {
        if (!this.notificationsContainer) {
            this.notificationsContainer = document.getElementById('notifications');
        }
    }
    addIcon(notification) {
        let iconElement = document.createElement('div');
        iconElement.className = 'iconfont';
        notification.appendChild(iconElement);
    }
    addMessage(notification, message) {
        let messageElement = document.createElement('p');
        messageElement.appendChild(document.createTextNode(message + '  '));
        notification.appendChild(messageElement);
        return messageElement;
    }
    createNotification(type) {
        let container = document.createElement('div');
        if (notificationTypes.indexOf(type) === -1) {
            type = notificationTypes[0];
        }
        container.className = 'notification ' + type;
        container.setAttribute('role', 'alert');
        return container;
    }
    addActionLink(messageContainer, text, url) {
        let linkElement = document.createElement('a');
        linkElement.href = url;
        linkElement.target = '_blank';
        linkElement.appendChild(document.createTextNode(text));
        linkElement.className = 'strong';
        messageContainer.appendChild(linkElement);
    }
    addActionElement(messageContainer, notificationId, text, callback) {
        let linkElement = document.createElement('a');
        linkElement.href = '#';
        linkElement.appendChild(document.createTextNode(text));
        linkElement.className = 'strong';
        linkElement.setAttribute('role', 'button');
        Dom.bind(linkElement, 'click', (e) => {
            e.preventDefault();
            callback(notificationId, e);
        });
        messageContainer.appendChild(linkElement);
    }
    addAction(messageContainer, notificationId, actionText, action) {
        let actionType = typeof action;
        if (actionType === 'function') {
            this.addActionElement(messageContainer, notificationId, actionText, action);
        }
        if (actionType === 'string') {
            this.addActionLink(messageContainer, actionText, action);
        }
    }
    dismissNotification(notificationId) {
        let notification;
        if (this.activeNotifications[notificationId] === undefined) {
            return false;
        }
        notification = this.activeNotifications[notificationId];
        notification.parentNode.removeChild(notification);
        delete this.activeNotifications[notificationId];
        this.events.publish('notificationDismissed', notificationId);
        return true;
    }
    addDismissButton(notification, notificationId) {
        let dismissContainer = document.createElement('div');
        let dismissButton = document.createElement('button');
        let dismissImage = document.createElement('span');
        dismissContainer.className = 'close';
        dismissButton.className = 'btn transparent circle';
        dismissButton.type = 'btn';
        dismissImage.className = 'iconfont cross';
        dismissImage.innerHTML = 'Dismiss notification';
        dismissButton.setAttribute('data-dismiss-id', notificationId);
        dismissImage.setAttribute('data-dismiss-id', notificationId);
        Dom.bind(dismissButton, 'click', (e) => {
            e.preventDefault();
            this.dismissNotification(notificationId);
        });
        dismissButton.appendChild(dismissImage);
        dismissContainer.appendChild(dismissButton);
        notification.appendChild(dismissContainer);
    }
    getIdForNewNotification() {
        this.notificationNumber++;
        return '' + this.notificationNumber;
    }
}
exports.AppLevel = AppLevel;
