"use strict";
const Dom = require('../../../utils/Dom');
const maxTitleLength = 60;
const maxMessageLength = 120;
class BrowserSupportedTypes {
    constructor(localisation) {
        this.localisation = localisation;
    }
    get SupportedTypes() {
        let supportedTypes = new Map();
        supportedTypes.set('UnreadMessage', {
            getNotificationData: (notification) => this.getUnreadMessageData(notification),
            shouldBeDisplayed: () => this.windowIsNotFocused(),
            isSecondary: true
        });
        supportedTypes.set('Audio', {
            getNotificationData: (notification) => this.getAudioCallData(notification),
            shouldBeDisplayed: () => this.windowIsNotFocused(),
            isSecondary: false
        });
        supportedTypes.set('incomingCallWithNoPlugin', {
            getNotificationData: (notification) => this.getAudioCallData(notification),
            shouldBeDisplayed: () => this.windowIsNotFocused(),
            isSecondary: false
        });
        return supportedTypes;
    }
    windowIsNotFocused() {
        if (document.hasFocus() === true) {
            return false;
        }
        return true;
    }
    trim(value, len) {
        if (value.length > len) {
            return value.substring(0, len - 3) + '...';
        }
        return value;
    }
    getUnreadMessageData(notification) {
        let notificationTitle = notification.title() || notification.sender.displayName();
        let notificationMessage = this.trim(notification.description(), maxMessageLength);
        notificationTitle = this.trim(notificationTitle, maxTitleLength);
        let windowVisibilityChanged = () => {
            if (Dom.windowIsVisible() === false) {
                return;
            }
            window.setTimeout(() => notification.active(false), 100);
        };
        return {
            title: notificationTitle,
            message: notificationMessage,
            imageUrl: notification.sender.avatar(),
            notificationId: 'newChat_' + notification.sender.uri(),
            callbacks: {
                onclick: () => {
                    notification.open();
                },
                onshow: () => {
                    window.setTimeout(() => notification.active(false), 7000);
                    Dom.bind(document, 'visibilitychange', windowVisibilityChanged);
                },
                onclose: () => {
                    Dom.unbind(document, 'visibilitychange', windowVisibilityChanged);
                }
            }
        };
    }
    getAudioCallData(notification) {
        let notificationMessage = this.localisation.getString('Toasts.IncomingCall');
        let notificationTitle = this.trim(notification.sender.displayName(), maxTitleLength);
        let windowVisibilityChanged = () => {
            if (Dom.windowIsVisible() === false) {
                return;
            }
            notification.dismissBrowserNotification();
        };
        return {
            title: notificationTitle,
            message: notificationMessage,
            imageUrl: notification.sender.avatar(),
            notificationId: 'newCall_' + notification.sender.uri(),
            callbacks: {
                onclick: () => {
                },
                onshow: () => {
                    Dom.bind(document, 'visibilitychange', windowVisibilityChanged);
                },
                onclose: () => {
                    Dom.unbind(document, 'visibilitychange', windowVisibilityChanged);
                }
            }
        };
    }
}
exports.BrowserSupportedTypes = BrowserSupportedTypes;
