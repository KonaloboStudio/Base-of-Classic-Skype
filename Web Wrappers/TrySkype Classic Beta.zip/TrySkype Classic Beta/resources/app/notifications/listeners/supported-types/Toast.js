"use strict";
class ToastSupportedTypes {
    constructor(events) {
        this.events = events;
    }
    get SupportedTypes() {
        let supportedTypes = new Map();
        supportedTypes.set('Audio', {
            templateId: 'shellToastCall',
            getToastData: (notification) => this.getAudioCallToastData(notification)
        });
        supportedTypes.set('incomingCallWithNoPlugin', {
            templateId: 'shellToastCallNoPlugin',
            getToastData: (notification) => this.getAudioCallWithNoPluginToastData(notification)
        });
        return supportedTypes;
    }
    getAudioCallToastData(notification) {
        let acceptVideo = () => {
            this.events.publish('hideMeApp');
            notification.accept('Video');
        };
        let acceptAudio = () => {
            this.events.publish('hideMeApp');
            notification.accept();
        };
        return {
            avatarUrl: notification.sender.avatar(),
            displayName: notification.sender.displayName(),
            acceptWithVideo: acceptVideo,
            acceptWithAudio: acceptAudio,
            reject: notification.decline,
            actionShortcuts: [
                {
                    'bodyEvent': true,
                    'eventName': 'keydown',
                    'eventKeys': {
                        altKey: true,
                        ctrlKey: false,
                        keyCode: 33
                    },
                    action: acceptAudio
                },
                {
                    'bodyEvent': true,
                    'eventName': 'keydown',
                    'eventKeys': {
                        altKey: true,
                        ctrlKey: true,
                        keyCode: 33
                    },
                    action: acceptVideo
                },
                {
                    'bodyEvent': true,
                    'eventName': 'keydown',
                    'eventKeys': {
                        altKey: true,
                        ctrlKey: false,
                        keyCode: 34
                    },
                    action: notification.decline
                }
            ]
        };
    }
    getAudioCallWithNoPluginToastData(notification) {
        return {
            avatarUrl: notification.sender.avatar(),
            displayName: notification.sender.displayName(),
            callToAction: notification.open,
            dismiss: () => notification.active(false)
        };
    }
    ;
}
exports.ToastSupportedTypes = ToastSupportedTypes;
