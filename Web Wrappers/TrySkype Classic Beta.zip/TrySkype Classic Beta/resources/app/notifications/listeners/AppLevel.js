"use strict";
class AppLevelListener {
    constructor(appLevelNotifications) {
        this.supportedTypes = {
            shellWarning: 'warning',
            shellSuccess: 'success',
            shellError: 'error',
            shellInfo: 'info'
        };
        this.appLevelNotifications = appLevelNotifications;
    }
    process(notification) {
        if (this.supportedTypes.hasOwnProperty(notification.type) === false) {
            return;
        }
        let type = this.supportedTypes[notification.type];
        let message = notification.description();
        let callToActionCallback;
        let callToActionText;
        if (typeof notification.open === 'function' && notification.title !== undefined) {
            callToActionCallback = notification.open;
            callToActionText = notification.title();
        }
        let notificationId = this.appLevelNotifications.display(type, message, callToActionText, callToActionCallback);
        notification.active.subscribe((value) => {
            if (!value) {
                this.appLevelNotifications.dismiss(notificationId);
            }
        });
    }
}
exports.AppLevelListener = AppLevelListener;
