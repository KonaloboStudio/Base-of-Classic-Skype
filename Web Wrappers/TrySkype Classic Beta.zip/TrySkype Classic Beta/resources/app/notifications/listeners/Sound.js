"use strict";
class SoundListener {
    constructor(soundNotifications) {
        this.supportedTypes = {
            'Audio': {
                fileId: 'incomingCall',
                loop: true
            },
            'incomingCallWithNoPlugin': {
                fileId: 'incomingCall',
                loop: true
            },
            'UnreadMessage': {
                fileId: 'incomingMessage',
                loop: false,
                isSecondary: true
            }
        };
        this.soundNotifications = soundNotifications;
    }
    process(notification, secondaryNotificationsEnabled) {
        if (this.supportedTypes.hasOwnProperty(notification.type) === false) {
            return;
        }
        let supType = this.supportedTypes[notification.type];
        if (secondaryNotificationsEnabled === false && supType.isSecondary === true) {
            return;
        }
        if (notification.canPlaySound === false) {
            return;
        }
        let fileId = supType.fileId;
        let loop = supType.loop;
        this.soundNotifications.play(fileId, loop);
        notification.active.subscribe((value) => {
            if (!value) {
                this.soundNotifications.stop(fileId);
            }
        });
    }
}
exports.SoundListener = SoundListener;
