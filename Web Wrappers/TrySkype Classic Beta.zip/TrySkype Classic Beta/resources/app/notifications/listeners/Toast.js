"use strict";
class ToastListener {
    constructor(supportedTypes, toast) {
        this.supportedTypes = supportedTypes;
        this.toast = toast;
    }
    process(notification) {
        let supType = this.supportedTypes.get(notification.type);
        if (!supType) {
            return;
        }
        let templateId = supType.templateId;
        let toastData = supType.getToastData(notification);
        let toastId = this.toast.display(templateId, toastData);
        notification.active.subscribe((value) => {
            if (!value) {
                this.toast.dismiss(toastId);
            }
        });
    }
    ;
}
exports.ToastListener = ToastListener;
