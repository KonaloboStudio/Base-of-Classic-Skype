"use strict";
class BrowserListener {
    constructor(supportedTypes, browserNotifications) {
        this.supportedTypes = supportedTypes;
        this.browserNotifications = browserNotifications;
    }
    process(notification, secondaryNotificationsEnabled) {
        let supType = this.supportedTypes.get(notification.type);
        if (!supType) {
            return;
        }
        if (secondaryNotificationsEnabled === false && supType.isSecondary === true) {
            return;
        }
        if (typeof supType.shouldBeDisplayed === 'function') {
            if (supType.shouldBeDisplayed() === false) {
                return;
            }
        }
        let notificationData = supType.getNotificationData(notification);
        let notificationId = this.browserNotifications.display(notificationData.title, notificationData.message, notificationData.imageUrl, notificationData.notificationId, notificationData.callbacks);
        notification.dismissBrowserNotification = () => {
            this.browserNotifications.dismiss(notificationId);
        };
        notification.active.subscribe((value) => {
            if (!value) {
                this.browserNotifications.dismiss(notificationId);
            }
        });
    }
}
exports.BrowserListener = BrowserListener;
