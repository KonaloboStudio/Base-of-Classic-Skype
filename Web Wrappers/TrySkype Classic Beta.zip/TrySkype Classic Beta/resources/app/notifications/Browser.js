"use strict";
class Browser {
    constructor(ipcSend) {
        this.activeNotifications = {};
        this.notificationNumber = 0;
        this.ipcSend = ipcSend;
    }
    display(title, message, imageUrl, notificationId, callbacks) {
        if (notificationId === undefined) {
            notificationId = this.getIdForNewNotification();
        }
        else if (typeof notificationId !== 'number' && typeof notificationId !== 'string') {
            return false;
        }
        if (callbacks === undefined) {
            callbacks = {};
        }
        else if (typeof callbacks !== 'object') {
            return false;
        }
        let param = { tag: notificationId, body: message };
        if (imageUrl) {
            param['icon'] = imageUrl;
        }
        let notification = new Notification(title, param);
        this.activeNotifications[notificationId] = notification;
        this.ipcSend('notification-delivered');
        notification.onclick = () => {
            this.ipcSend('notification-activated');
            if (typeof callbacks.onclick === 'function') {
                callbacks.onclick();
            }
        };
        notification.onclose = () => {
            this.dismiss(notificationId);
            if (typeof callbacks.onclose === 'function') {
                callbacks.onclose();
            }
        };
        if (typeof callbacks.onshow === 'function') {
            notification.onshow = callbacks.onshow;
        }
        return notificationId;
    }
    ;
    dismiss(notificationId) {
        if (typeof notificationId !== 'string' && notificationId !== 'number') {
            return false;
        }
        if (this.activeNotifications.hasOwnProperty(notificationId) === false) {
            return false;
        }
        this.activeNotifications[notificationId].close();
        delete this.activeNotifications[notificationId];
        return true;
    }
    dismissAll() {
        for (let notificationId in this.activeNotifications) {
            if (this.activeNotifications.hasOwnProperty(notificationId)) {
                this.dismiss(notificationId);
            }
        }
    }
    getIdForNewNotification() {
        this.notificationNumber++;
        return this.notificationNumber;
    }
}
exports.Browser = Browser;
