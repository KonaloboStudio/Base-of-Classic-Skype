"use strict";
function init(appLevel, skype) {
    skype.on('checking-for-update', () => {
        let notificationId = appLevel.display('info', 'Checking for updates...', 'Close', () => {
            appLevel.dismiss(notificationId);
        });
    });
    skype.on('platform-updates-downloaded', () => {
        let notificationId = appLevel.display('info', 'New version is available.', 'Restart and install updates', () => {
            appLevel.dismiss(notificationId);
            skype.emit('restart-and-update');
        });
    });
    skype.on('updates-found', () => {
        let notificationId = appLevel.display('info', 'New version is available.', 'Reload', () => {
            appLevel.dismiss(notificationId);
            skype.emit('reload');
        });
    });
    skype.on('update-not-available', () => {
        let notificationId = appLevel.display('info', 'There are no updates currently available.', 'Close', () => {
            appLevel.dismiss(notificationId);
        });
    });
    skype.on('update-error', () => {
        let notificationId = appLevel.display('info', 'An application update failed.', 'Close', () => {
            appLevel.dismiss(notificationId);
        });
    });
}
exports.init = init;
