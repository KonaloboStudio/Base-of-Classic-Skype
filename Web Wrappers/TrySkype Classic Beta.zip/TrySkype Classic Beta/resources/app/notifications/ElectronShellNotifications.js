"use strict";
function init(appLevel, skype, localisation) {
    let fullScreenEnteredNotificationId;
    skype.on('enter-full-screen', () => {
        fullScreenEnteredNotificationId = appLevel.display('info', localisation.getString('Notifications.FullScreenEntered'), localisation.getString('Notifications.ExitFullScreen'), () => {
            skype.emit('force-leave-full-screen');
            appLevel.dismiss(fullScreenEnteredNotificationId);
        });
    });
    skype.on('leave-full-screen', () => {
        appLevel.dismiss(fullScreenEnteredNotificationId);
    });
}
exports.init = init;
