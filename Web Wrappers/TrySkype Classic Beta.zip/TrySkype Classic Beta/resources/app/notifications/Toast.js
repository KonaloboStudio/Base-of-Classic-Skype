"use strict";
const Dom = require('../utils/Dom');
class Toast {
    constructor(templates) {
        this.toastNumber = 0;
        this.activeToasts = {};
        this.activeToastEvents = [];
        this.templates = templates;
    }
    display(toastTemplateId, toastData) {
        this.setToastsContainer();
        let clonedTemplate = this.templates.clone(toastTemplateId);
        if (!clonedTemplate) {
            return null;
        }
        let compiledTempl = this.templates.compile(clonedTemplate, toastData);
        let toastId = this.getIdForNewToast();
        let toast = compiledTempl.templateElement;
        this.activeToasts[toastId] = toast;
        this.activeToastEvents[toastId] = compiledTempl.events;
        this.notificationsContainer.appendChild(toast);
        toast.style.display = 'block';
        return toastId;
    }
    dismiss(toastId) {
        let toastDismissed = this.dismissToast(toastId);
        return toastDismissed;
    }
    getDisplayedToasts() {
        return this.activeToasts;
    }
    dismissAll() {
        for (let toastId in this.activeToasts) {
            if (this.activeToasts.hasOwnProperty(toastId)) {
                this.dismiss(toastId);
            }
        }
    }
    setToastsContainer() {
        if (!this.notificationsContainer) {
            this.notificationsContainer = document.getElementById('toasts');
        }
    }
    getIdForNewToast() {
        this.toastNumber++;
        return '' + this.toastNumber;
    }
    dismissToast(toastId) {
        if (this.activeToasts[toastId] === undefined) {
            return false;
        }
        let toast = this.activeToasts[toastId];
        Dom.unbindEvents(this.activeToastEvents[toastId]);
        toast.parentNode.removeChild(toast);
        delete this.activeToasts[toastId];
        delete this.activeToastEvents[toastId];
        return true;
    }
}
exports.Toast = Toast;
