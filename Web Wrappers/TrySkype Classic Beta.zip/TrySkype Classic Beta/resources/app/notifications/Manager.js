"use strict";
class Manager {
    constructor() {
        this.listeners = [];
        this.secondaryNotifEnabled = false;
    }
    notify(notification) {
        for (let i = 0; i < this.listeners.length; i++) {
            this.listeners[i].process(notification, this.secondaryNotifEnabled);
        }
    }
    secondaryNotificationsEnabled(value) {
        if (typeof value !== 'boolean') {
            return;
        }
        this.secondaryNotifEnabled = value;
    }
    addListener(listener) {
        if (typeof listener !== 'object' || listener === null) {
            return false;
        }
        if (listener.process === undefined) {
            return false;
        }
        if (this.listeners.indexOf(listener) !== -1) {
            return false;
        }
        this.listeners.push(listener);
        return true;
    }
}
exports.Manager = Manager;
