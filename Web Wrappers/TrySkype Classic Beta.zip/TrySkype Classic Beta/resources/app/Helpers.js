"use strict";
class Encoding {
    guidCreate() {
        let r = new Array(8);
        function formatAsHex(n) {
            let hex = n.toString(16);
            let padding = 4 - hex.length;
            for (let i = 0; i < padding; i += 1) {
                hex = '0' + hex;
            }
            return hex;
        }
        for (let i = 0; i < r.length; i += 2) {
            let val = Math.floor(Math.random() * 0x100000000);
            r[i] = formatAsHex(val & 0xFFFF);
            r[i + 1] = formatAsHex(val >>> 16);
            if ((i + 1) === 3) {
                r[i + 1] = '4' + r[i + 1].substring(1);
            }
        }
        return r[0] + r[1] + '-' + r[2] + '-' + r[3] + '-' + r[4] + '-' + r[5] + r[6] + r[7];
    }
    ;
}
exports.Encoding = Encoding;
class Page {
    static bindEvent(elem, eventName, func) {
        elem.addEventListener(eventName, func, false);
    }
    static injectScript(url, successCallback, errorCallback) {
        let script = document.createElement('script');
        script.async = true;
        script.setAttribute('src', url);
        Page.bindEvent(script, 'load', successCallback);
        if (typeof errorCallback === 'function') {
            Page.bindEvent(script, 'error', errorCallback);
        }
        document.body.appendChild(script);
    }
}
exports.Page = Page;
class Ui {
    static getPosition(element) {
        if (typeof element.getBoundingClientRect !== 'function') {
            return false;
        }
        let coordinates = element.getBoundingClientRect();
        let leftPosition = coordinates.left - +element.style.marginLeft - +element.style.marginRight;
        let topPosition = coordinates.top - +element.style.marginTop - +element.style.marginBottom;
        return { left: leftPosition, top: topPosition };
    }
    ;
    static hasClass(elem, className) {
        let re = new RegExp('(?:^|\\s)' + className + '(?!\\S)', 'g');
        if (elem.className.match(re)) {
            return true;
        }
        return false;
    }
    ;
    static addClass(elem, className) {
        if (this.hasClass(elem, className) === true) {
            return false;
        }
        elem.className += ' ' + className;
        return true;
    }
    ;
    static removeClass(elem, className) {
        if (this.hasClass(elem, className) === false) {
            return false;
        }
        let re = new RegExp('(?:^|\\s)' + className + '(?!\\S)', 'g');
        elem.className = elem.className.replace(re, '');
        return true;
    }
    ;
    static bind(elem, eventName, func, useCapture = false) {
        elem.addEventListener(eventName, func, useCapture);
        return {
            elem: elem,
            eventName: eventName,
            boundFunction: func
        };
    }
    static unbind(elem, eventName, func) {
        elem.removeEventListener(eventName, func, false);
    }
    static makePageVisibleForAT() {
        let firstLevelBodyElements = document.querySelectorAll('body > div');
        for (let i = 0; i < firstLevelBodyElements.length; i++) {
            firstLevelBodyElements[i].removeAttribute('aria-hidden');
        }
        return true;
    }
    ;
    static makePageInvisibleForAT(elem) {
        let firstLevelBodyElements = document.querySelectorAll('body > div');
        for (let i = 0; i < firstLevelBodyElements.length; i++) {
            if (firstLevelBodyElements[i] === elem) {
                continue;
            }
            firstLevelBodyElements[i].setAttribute('aria-hidden', 'true');
        }
        return true;
    }
    ;
    static bindElementEvent(bindElement, eventName, eventKeys, action) {
        let bindFunction = function (e) {
            let keys = Object.keys(eventKeys);
            for (let i = 0; i < keys.length; i++) {
                let key = keys[i];
                if (e[key] === undefined || e[key] !== eventKeys[key]) {
                    return;
                }
            }
            action();
        };
        this.bind(bindElement, eventName, bindFunction, false);
        return bindFunction;
    }
    static bindEvents(element, events) {
        let bindElement = element;
        let eventsBound = [];
        let eventBound;
        for (let i = 0; i < events.length; i++) {
            let eventProperties = events[i];
            if (eventProperties.bodyEvent !== undefined && eventProperties.bodyEvent === true) {
                bindElement = document.body;
            }
            if (eventProperties.eventKeys === undefined) {
                this.bind(bindElement, eventProperties.eventName, eventProperties.action, false);
                eventBound = this.createEventDataObj(bindElement, eventProperties.eventName, eventProperties.action);
                eventsBound.push(eventBound);
                continue;
            }
            let boundFunction = this.bindElementEvent(bindElement, eventProperties.eventName, eventProperties.eventKeys, eventProperties.action);
            eventBound = this.createEventDataObj(bindElement, eventProperties.eventName, boundFunction);
            eventsBound.push(eventBound);
        }
        return eventsBound;
    }
    ;
    static unbindEvents(events) {
        for (let eventData of events) {
            this.unbind(eventData.elem, eventData.eventName, eventData.boundFunction);
        }
    }
    static createEventDataObj(elem, eventName, boundFunction) {
        return {
            elem: elem,
            eventName: eventName,
            boundFunction: boundFunction
        };
    }
}
Ui.windowVisibilityChangeEventName = 'visibilitychange';
Ui.cssTransitionsSupported = true;
exports.Ui = Ui;
