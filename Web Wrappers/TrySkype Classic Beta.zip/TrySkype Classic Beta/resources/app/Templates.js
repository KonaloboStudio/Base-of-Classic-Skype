"use strict";
const Helpers_1 = require('./Helpers');
const StringHelper = require('./utils/StringHelper');
class Templates {
    constructor(document) {
        this.document = document;
    }
    replaceHtml(elements, templateData) {
        let length = elements.length;
        for (let i = 0; i < length; i++) {
            let variableName = elements[i].getAttribute('data-html');
            if (templateData.hasOwnProperty(variableName) === false || typeof variableName !== 'string') {
                continue;
            }
            elements[i].innerHTML = StringHelper.escapeHtmlEntities(templateData[variableName]);
        }
    }
    bindClicks(elements, templateData) {
        let eventsBound = [];
        for (let i = 0; i < elements.length; i++) {
            let variableName = elements[i].getAttribute('data-click');
            if (templateData.hasOwnProperty(variableName) === false || typeof templateData[variableName] !== 'function') {
                continue;
            }
            let eventdata = Helpers_1.Ui.bind(elements[i], 'click', templateData[variableName]);
            eventsBound.push(eventdata);
        }
        return eventsBound;
    }
    bindEvents(elements, templateData) {
        let eventsBound = [];
        for (let i = 0; i < elements.length; i++) {
            let variableName = elements[i].getAttribute('data-events');
            if (templateData.hasOwnProperty(variableName) === false || typeof templateData[variableName] !== 'object') {
                continue;
            }
            let events = Helpers_1.Ui.bindEvents(elements[i], templateData[variableName]);
            eventsBound = eventsBound.concat(events);
        }
        return eventsBound;
    }
    replaceAttributes(elements, templateData) {
        for (let i = 0; i < elements.length; i++) {
            let valueParts = elements[i].getAttribute('data-attr').split('|');
            if (valueParts.length !== 2) {
                continue;
            }
            let attributeName = valueParts[0];
            let variableName = valueParts[1];
            if (templateData.hasOwnProperty(variableName) === false || typeof variableName !== 'string') {
                continue;
            }
            let escapedValue = StringHelper.escapeHtmlEntities(templateData[variableName]);
            elements[i].setAttribute(attributeName, escapedValue);
        }
    }
    clone(templateId) {
        let elementToClone = this.document.getElementById(templateId);
        if (elementToClone === null) {
            return null;
        }
        let clonedElement = elementToClone.cloneNode(true);
        clonedElement.removeAttribute('id');
        return clonedElement;
    }
    compile(templateElement, templateData) {
        this.replaceHtml(templateElement.querySelectorAll('[data-html]'), templateData);
        this.replaceAttributes(templateElement.querySelectorAll('[data-attr]'), templateData);
        let clicksBound = this.bindClicks(templateElement.querySelectorAll('[data-click]'), templateData);
        let eventsBound = this.bindEvents(templateElement.querySelectorAll('[data-events]'), templateData);
        let events = clicksBound.concat(eventsBound);
        return { templateElement: templateElement, events: events };
    }
}
exports.Templates = Templates;
