"use strict";
const Helpers_1 = require('./Helpers');
class KeyboardNavigation {
    constructor(document) {
        this.allowedContainersHistory = [];
        this.allowedContainers = [];
        Helpers_1.Ui.bind(document, 'focus', (e) => { this.tabConstrain(e); }, true);
    }
    liftLastRestriction() {
        if (this.allowedContainersHistory.length <= 1) {
            this.allowedContainersHistory = [];
            this.allowedContainers = [];
            return;
        }
        this.allowedContainersHistory.pop();
        this.allowedContainers = this.allowedContainersHistory[this.allowedContainersHistory.length - 1];
    }
    restrictTabbing(allowedElementsArray) {
        if (!allowedElementsArray) {
            return false;
        }
        this.allowedContainersHistory.push(allowedElementsArray);
        this.allowedContainers = allowedElementsArray;
        this.activeContainer = allowedElementsArray[0];
        return true;
    }
    tabConstrain(e) {
        if (this.allowedContainers.length === 0) {
            return;
        }
        this.targetElement = e.target;
        for (let i = 0; i < this.allowedContainers.length; i++) {
            if (this.allowedContainers[i].contains(this.targetElement) === true) {
                this.activeContainer = this.allowedContainers[i];
                return;
            }
        }
        this.nextElement = this.getNextElement();
        this.nextElement.setAttribute('tabindex', '-1');
        this.nextElement.focus();
    }
    getNextElement() {
        let nodePosition = this.activeContainer.compareDocumentPosition(this.targetElement);
        nodePosition = (nodePosition === 10) ? Node.DOCUMENT_POSITION_PRECEDING : nodePosition;
        let container = null;
        if (nodePosition === Node.DOCUMENT_POSITION_FOLLOWING) {
            container = this.allowedContainers[this.allowedContainers.indexOf(this.activeContainer) + 1];
            return (container) ? container : this.allowedContainers[0];
        }
        if (nodePosition === Node.DOCUMENT_POSITION_PRECEDING) {
            container = this.allowedContainers[this.allowedContainers.indexOf(this.activeContainer) - 1];
            return (container) ? container : this.allowedContainers[this.allowedContainers.length - 1];
        }
        return null;
    }
}
exports.KeyboardNavigation = KeyboardNavigation;
