"use strict";
const path = require('path');
const Configuration_1 = require('./Configuration');
const defaultBundleDir = '/bundle';
exports.config = {
    env: 'electron',
    pageId: 'main',
    defaultPageTitle: Configuration_1.default.appName,
    ecsFileName: 'ecs.json',
    assetsBaseUrl: '/assets',
    appBaseUrl: '/swx',
    basePath: `file://${defaultBundleDir}`,
    bundlePath: path.join(Configuration_1.default.rootDir, defaultBundleDir),
    eligibilityCheck: {
        enabled: false
    },
    supportedLanguages: 'en,ar,bg,cs,da,de,el,es,et,fi,fr,he,hi,hu,id,it,ja,ko,nl,no,pl,pt,pt-br,ro,ru,sv,tr,uk,zh-Hans,zh-Hant'.split(','),
    Urls: {
        mainUrl: 'file:///swx/html/main.html',
        myaccountUrl: 'https://secure.skype.com',
        serverPingUrl: 'https://web.skype.com/api/v1/session-ping',
        cookiesPrivacyUrl: 'https://go.skype.com/privacy/'
    },
    languageRedirectUrl: 'file:///swx/html/{language}/main.html',
    languageSetApi: 'https://api.skype.com/users/{username}/language',
    sdk: {
        name: 'webShell/Components/SDK',
        url: 'file:///swx/SkypeBootstrap-int.js',
        breakCache: true,
        apiKey: Configuration_1.default.biAppKey,
        environment: '',
        versioning: {
            desiredVersion: '',
            componentQueryParam: 'version'
        }
    },
    splashScreenDisplayTime: 10000,
    tokenHandoverAllowed: true
};
