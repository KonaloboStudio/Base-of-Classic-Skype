"use strict";
const Helpers_1 = require('./Helpers');
const Config_1 = require('./Config');
const skype_electron_wrapper_1 = require('skype-electron-wrapper');
class Sdk {
    constructor(session, events, title, manager) {
        this.session = session;
        this.events = events;
        this.title = title;
        this.manager = manager;
    }
    init() {
        let sdkConfig = {
            apiKey: Config_1.config.sdk.apiKey,
            environment: Config_1.config.sdk.environment,
            locale: skype_electron_wrapper_1.language.getLocale(),
            userId: this.session.get('skypeId'),
            correlationIds: {
                hostProperty: 'SkypePortal',
                sessionId: this.session.get('externalSessionId') || this.session.get('sessionId'),
                tabId: this.session.get('sessionId')
            }
        };
        let root = window['Skype'];
        let configWrapper = {
            initParams: sdkConfig,
            config: root.config.ecsConfig,
            configLoadDuration: 0,
            packageLoadDuration: 0
        };
        root.onExperienceLoaded = (experience) => {
            experience.init(configWrapper, (swxApi) => this.successCallback(swxApi), () => console.log('SDK initialization failed.'));
            delete root.onExperienceLoaded;
        };
        Helpers_1.Page.injectScript(root.config.packageUrl, () => console.log('SDK loaded'), () => console.log('Failed to load SDK'));
    }
    logout() {
        if (this.signOut) {
            this.signOut();
        }
    }
    changeStatus(status) {
        if (this.statusObservable) {
            let statusSwx = Sdk.swxStatusMap[status] || Sdk.swxStatusMap.online;
            this.statusObservable(statusSwx);
        }
    }
    handleSkypeUri(skypeUri) {
        if (this.navigateBySkypeUri) {
            console.log('Navigate by Skype URI');
            this.navigateBySkypeUri(skypeUri);
        }
    }
    successCallback(swxApi) {
        const skype = window['Skype'];
        console.log('Loaded SWX version: ' + swxApi.getVersion());
        skype.notifyStartupEnded();
        swxApi.setAuthProvider({
            type: 'skypeToken',
            getToken: () => {
                return this.session.get('skypeToken');
            }
        });
        swxApi.renderContent('#chatComponent');
        swxApi.me.status.subscribe((status) => {
            let data = {
                avatarUrl: swxApi.me.avatar(),
                displayName: swxApi.me.displayName(),
                status: status.toLowerCase()
            };
            this.events.publish('userPresenceChanged', data);
        });
        swxApi.subscribeUI('swx:timeline:loaded', () => {
            this.events.publish('pageRendered', performance.now());
        });
        swxApi.setNotificationHandler((notification) => {
            this.manager.notify(notification);
        });
        this.callback2(swxApi);
        let data = {
            avatarUrl: swxApi.me.avatar(),
            displayName: swxApi.me.displayName(),
            status: swxApi.me.status().toLowerCase()
        };
        this.events.publish('userPresenceChanged', data);
    }
    callback2(swxApi) {
        let contentLoaded = false;
        let userHasContacts = false;
        try {
            this.signOut = swxApi.signOut;
            this.statusObservable = swxApi.me.status;
            this.navigateBySkypeUri = swxApi.navigateBySkypeUri;
            swxApi.renderMe('#meComponent');
            swxApi.me.authenticated.subscribe((param) => {
                if (!param) {
                    let skype = window['Skype'];
                    skype.logout();
                }
            });
            swxApi.renderSidebar('#timelineComponent', { sidebarPosition: 'left' });
            swxApi.subscribeUI('swx:timeline:loaded', () => {
                let autoAction = this.session.get('autoaction');
                let createEmptyConversationEnabled = (autoAction === 'cc');
                if (createEmptyConversationEnabled) {
                    this.session.remove('autoaction');
                    swxApi.startConversation([], [], (conversation) => {
                        if (!conversation.isJoinable || !conversation.makeJoinable) {
                            return;
                        }
                        if (!conversation.isJoinable()) {
                            conversation.makeJoinable();
                        }
                    });
                }
                const skypeUri = skype_electron_wrapper_1.getSkypeUri();
                let uri = skypeUri.getUri();
                if (uri) {
                    this.handleSkypeUri(uri);
                }
            });
            swxApi.activity.unreadConversations.subscribe((unreadConversationsCount) => {
                this.events.publish('unreadConversationsUpdate', unreadConversationsCount);
            });
            swxApi.me.numberOfNonAgentContacts.subscribe((contacts) => {
                this.events.publish('numberOfContactsUpdated', contacts);
            });
            this.session.remove('threadId');
            if (!this.session.get('newConversation') || swxApi.newConversation === undefined) {
                return;
            }
            function displayNewConversation() {
                if (!userHasContacts || contentLoaded === false) {
                    return;
                }
                swxApi.newConversation();
            }
            swxApi.subscribeUI('swx:content:loaded', () => {
                contentLoaded = true;
                let threadId = this.session.get('threadId');
                if (threadId) {
                    swxApi.joinConversation(threadId, ['Chat']);
                }
                else {
                    displayNewConversation();
                }
            });
            swxApi.me.numberOfNonAgentContacts.subscribe((contacts) => {
                if (userHasContacts !== undefined) {
                    return;
                }
                userHasContacts = (contacts > 0);
                if (userHasContacts === true) {
                    displayNewConversation();
                }
            });
            this.session.remove('newConversation');
        }
        catch (e) {
            console.log('Exception in callback: ' + e.message);
        }
    }
}
Sdk.swxStatusMap = {
    online: 'Online',
    offline: 'Offline',
    hidden: 'Hidden',
    away: 'Away',
    donotdisturb: 'DoNotDisturb'
};
exports.Sdk = Sdk;
