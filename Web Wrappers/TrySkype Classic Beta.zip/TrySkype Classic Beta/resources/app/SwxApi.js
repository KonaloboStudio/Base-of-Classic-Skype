"use strict";
const electron = require('electron');
const path = require('path');
const fs = require('fs');
const events_1 = require('events');
const skype_electron_wrapper_1 = require('skype-electron-wrapper');
const Configuration_1 = require('./Configuration');
const Config_1 = require('./Config');
const Objects_1 = require('./utils/Objects');
const shell = require('./ShellLoader');
const ipc = electron.ipcRenderer;
function apiForMain() {
    customizeMainPage();
    const authenticationManager = skype_electron_wrapper_1.getAuthenticationManager();
    const skype = window['Skype'] = window['Skype'] || Object.create(events_1.EventEmitter.prototype);
    skype.isElectron = true;
    skype.ipcSend = function (channel, ...args) {
        ipc.send(channel, ...args);
    };
    skype.config = getConfig();
    shell.apiForShell(skype);
    updateEventForwarding(skype);
    authEventForwarding(skype);
    windowShellEventForwarding(skype);
    skype.getSkypeModule = () => {
        return module.require('skype-module');
    };
    skype.notifyStartupEnded = () => {
        ipc.send('application-startup-end');
    };
    skype.registerPresence = (registrarUrl, payload) => {
        let token = authenticationManager.getSkypeToken();
        return skype_electron_wrapper_1.registerPresence(token, registrarUrl, payload);
    };
    skype.refreshAuthentication = () => {
        return new Promise((resolve, reject) => {
            authenticationManager.performForcedRefresh().then((authData) => {
                resolve(authData.skypeToken);
            }).catch((error) => {
                reject(error);
            });
        });
    };
    skype.on('reload', () => skype_electron_wrapper_1.navigateTo(Configuration_1.default));
    skype.logout = () => {
        authenticationManager.logout();
    };
    skype.forceQuit = () => {
        electron.app.quit();
    };
    handleSkypeUri(skype);
}
exports.apiForMain = apiForMain;
function getConfig() {
    let bundleConfig = readEcsFile(path.join(Config_1.config.bundlePath, Config_1.config.ecsFileName));
    let swxPackageUrl = `${Config_1.config.basePath}${Configuration_1.default.packageUrl}`;
    const customConfig = {
        'appBaseUrl': `${Config_1.config.basePath}${Config_1.config.appBaseUrl}`,
        'assetsBaseUrl': `${Config_1.config.basePath}${Config_1.config.assetsBaseUrl}`,
        'biAppName': Configuration_1.default.biAppKey,
        'webApiService': {
            'pingDelayTime': {
                min: 2,
                max: 2
            }
        },
        'displayAppVersion': false
    };
    const { appOverride } = skype_electron_wrapper_1.getEcsConfig().getData();
    Objects_1.deepMerge(bundleConfig, customConfig, appOverride);
    console.log('SWX ECS Config: ', bundleConfig);
    return { packageUrl: swxPackageUrl, ecsConfig: bundleConfig };
}
function customizeMainPage() {
    document.addEventListener('DOMContentLoaded', function () {
        function isProfileOpen() {
            return !!document.querySelector('div.Me--expanded');
        }
        function openProfile() {
            const elem = document.querySelector('.Me-displayName');
            if (!isProfileOpen() && elem) {
                elem.click();
            }
        }
        function closeProfile() {
            const elem = document.querySelector('.Me-collapseBtn');
            if (isProfileOpen() && elem) {
                elem.click();
            }
        }
        function isSettingsOpen() {
            const elem = document.getElementById('menuItem-userSettings');
            return elem && !!elem.classList.contains('active');
        }
        function openSettings() {
            const elem = document.getElementById('menuItem-userSettings');
            if (!isSettingsOpen() && elem) {
                elem.click();
            }
        }
        function closeSettings() {
            const elem = document.getElementById('menuItem-userSettings');
            if (isSettingsOpen() && elem) {
                elem.click();
            }
        }
        function openNewConversation() {
            document.getElementById('menuItem-newChat').click();
        }
        ipc.on('open-settings', () => {
            closeProfile();
            openSettings();
        });
        ipc.on('close-settings', () => {
            closeProfile();
            closeSettings();
        });
        ipc.on('open-profile', () => {
            closeSettings();
            openProfile();
        });
        ipc.on('close-profile', () => {
            closeProfile();
            closeSettings();
        });
        ipc.on('new-conversation', () => {
            closeProfile();
            closeSettings();
            openNewConversation();
        });
        ipc.on('change-presence', (event, status) => {
            window['Skype'].Shell.Sdk.changeStatus(status);
        });
        ipc.on('logout', () => {
            window['Skype'].Shell.Sdk.logout();
        });
    });
}
exports.customizeMainPage = customizeMainPage;
function handleSkypeUri(skype) {
    const skypeUri = skype_electron_wrapper_1.getSkypeUri();
    ipc.on('skype-uri-available', () => {
        let uri = skypeUri.getUri();
        skype.Shell.Sdk.handleSkypeUri(uri);
    });
}
function authEventForwarding(skype) {
    ipc.on('auth-data-updated', (event, authData) => {
        skype.emit('auth-data-updated', authData);
    });
}
function updateEventForwarding(skype) {
    ipc.on('checking-for-update', () => {
        skype.emit('checking-for-update');
    });
    ipc.on('update-available', () => {
        skype.emit('platform-updates-available');
    });
    ipc.on('update-downloaded', () => {
        skype.emit('platform-updates-downloaded');
    });
    ipc.on('update-not-available', () => {
        skype.emit('update-not-available');
    });
    ipc.on('update-error', () => {
        skype.emit('update-error');
    });
    skype.on('restart-and-update', () => {
        skype.ipcSend('update-quit-and-install');
    });
}
function windowShellEventForwarding(skype) {
    ipc.on('enter-full-screen', () => {
        skype.emit('enter-full-screen');
    });
    ipc.on('leave-full-screen', () => {
        skype.emit('leave-full-screen');
    });
    skype.on('force-leave-full-screen', () => {
        ipc.send('force-leave-full-screen');
    });
}
function readEcsFile(ecsFile) {
    let config = JSON.parse(fs.readFileSync(ecsFile, 'utf8').replace(/^\uFEFF/, ''));
    return config;
}
