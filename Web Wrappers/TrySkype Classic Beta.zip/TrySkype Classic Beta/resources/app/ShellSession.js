"use strict";
const skype_electron_wrapper_1 = require('skype-electron-wrapper');
class ShellSession {
    constructor() {
        this.sessionData = {};
    }
    get(property) {
        return this.sessionData[property];
    }
    set(property, value) {
        if (value === undefined || typeof value === 'function') {
            return false;
        }
        this.sessionData[property] = value;
        return true;
    }
    remove(property) {
        delete this.sessionData[property];
        return true;
    }
    updateAuthProperties(token) {
        if (!token) {
            return;
        }
        let parsedToken = skype_electron_wrapper_1.SkypeToken.parse(token);
        this.sessionData['skypeId'] = parsedToken.skypeId;
        this.sessionData['skypeToken'] = parsedToken.value;
        this.sessionData['skypeTokenExpiration'] = parsedToken.expiration;
    }
}
exports.ShellSession = ShellSession;
