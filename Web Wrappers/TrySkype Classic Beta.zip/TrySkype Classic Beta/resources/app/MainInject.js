let skype = window['Skype'];
let session = skype.Shell.ShellSession;
let encoding = skype.Shell.Encoding;
let splashScreen = skype.Shell.SplashScreen;
if (session.get('sessionId') === undefined) {
    session.set('sessionId', encoding.guidCreate());
}
skype.ShellLocalization.init(session);
skype.Shell.Sdk.init();
splashScreen.show();
