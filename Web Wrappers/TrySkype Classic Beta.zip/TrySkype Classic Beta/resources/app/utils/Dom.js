"use strict";
function bind(elem, eventName, func, useCapture = false) {
    elem.addEventListener(eventName, func, useCapture);
    return {
        elem: elem,
        eventName: eventName,
        boundFunction: func
    };
}
exports.bind = bind;
function unbind(elem, eventName, func) {
    elem.removeEventListener(eventName, func, false);
}
exports.unbind = unbind;
function unbindEvents(events) {
    for (let eventData of events) {
        this.unbind(eventData.elem, eventData.eventName, eventData.boundFunction);
    }
}
exports.unbindEvents = unbindEvents;
function windowIsVisible() {
    return document.hidden;
}
exports.windowIsVisible = windowIsVisible;
