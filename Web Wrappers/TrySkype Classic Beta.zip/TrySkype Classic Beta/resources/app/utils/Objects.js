"use strict";
function deepMerge(result, ...sources) {
    function mergeInto(target) {
        return function partialMerge(source) {
            Object.keys(source).forEach(key => {
                if (target[key] == null ||
                    Array.isArray(target[key]) ||
                    typeof source[key] !== 'object' ||
                    Array.isArray(source[key])) {
                    target[key] = source[key];
                    return;
                }
                if (source[key] === null) {
                    target[key] = null;
                    return;
                }
                mergeInto(target[key])(source[key]);
            });
        };
    }
    sources.forEach(mergeInto(result));
    return result;
}
exports.deepMerge = deepMerge;
