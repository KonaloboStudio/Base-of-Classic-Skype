"use strict";
const skype_electron_wrapper_1 = require('skype-electron-wrapper');
class ShellLocalization {
    init(session) {
        skype_electron_wrapper_1.domLocaliser.translateDomElement(document.head);
        skype_electron_wrapper_1.domLocaliser.translateDomElement(document.body);
        session.set('language', skype_electron_wrapper_1.language.getLanguageCodeInSkypeFormat());
    }
}
exports.ShellLocalization = ShellLocalization;
