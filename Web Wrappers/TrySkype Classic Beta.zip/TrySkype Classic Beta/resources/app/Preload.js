"use strict";
const swxApi = require('./SwxApi');
const Configuration_1 = require('./Configuration');
const skype_electron_wrapper_1 = require('skype-electron-wrapper');
const electron_1 = require('electron');
const { Menu, MenuItem } = electron_1.remote;
if (process.platform === 'linux') {
    electron_1.crashReporter.start({
        productName: Configuration_1.default.appShortName,
        companyName: 'Skype',
        submitURL: Configuration_1.default.crashReporterUrl,
        autoSubmit: true,
        extra: {
            environment: Configuration_1.default.environment
        }
    });
}
skype_electron_wrapper_1.initPreload();
if (location.hostname === '' && !location.pathname.startsWith('/common/')) {
    swxApi.apiForMain();
    createContextMenu();
}
function createContextMenu() {
    let menu = new Menu();
    menu.append(new MenuItem({
        label: skype_electron_wrapper_1.language.getString('Menu.CutLabel'),
        accelerator: 'CmdOrCtrl+X',
        role: 'cut'
    }));
    menu.append(new MenuItem({
        label: skype_electron_wrapper_1.language.getString('Menu.CopyLabel'),
        accelerator: 'CmdOrCtrl+C',
        role: 'copy'
    }));
    menu.append(new MenuItem({
        label: skype_electron_wrapper_1.language.getString('Menu.PasteLabel'),
        accelerator: 'CmdOrCtrl+V',
        role: 'paste'
    }));
    menu.append(new MenuItem({
        label: skype_electron_wrapper_1.language.getString('Menu.SelectAllLabel'),
        accelerator: 'CmdOrCtrl+A',
        role: 'selectall'
    }));
    window.addEventListener('contextmenu', (e) => {
        let node = e.target;
        if (node.nodeName === 'TEXTAREA' || node.nodeName === 'INPUT') {
            e.preventDefault();
            e.stopPropagation();
            menu.popup(electron_1.remote.getCurrentWindow());
        }
    }, false);
}
